# BBC News Text Classification and Recommendations

This project trains a BBC News text classifier (Logistic Regression by default) on TF-IDF features and provides recommendations using three methods: KD-Tree (on dense TF-IDF), brute-force cosine similarity, and BM25 (bestmatch25). A Streamlit web app serves predictions and top-10 similar articles with per-method timings.

## Project Structure
```
bbc_classification_kdtree/
│── data/
│   └── bbc-news-data.csv.zip
│── models/
│   ├── classifier.pkl
│   ├── vectorizer.pkl
│   ├── kdtree.pkl
│   ├── tfidf_matrix.pkl
│   └── corpus_meta.pkl
│── app.py
│── train_model.py
│── requirements.txt
│── README.md
```

## 1) Data Collection
- Place the dataset archive at `data/bbc-news-data.csv.zip`.
- The ZIP must contain a CSV with at least the columns: `text`, `category`. Optional: `title`.

## 2) Data Preprocessing
- Lowercasing, punctuation/number removal
- Stopword removal
- Lemmatization
- Implemented in `train_model.py` using NLTK

## 3) Feature Engineering
- TF-IDF with up to 30k features, 1-2 grams
- Trained on train split; full corpus transformed for recommendation indices

## 4) Model Training
- Split: 80/20 stratified
- Classifier options: Logistic Regression (default), MultinomialNB, LinearSVC
- Metrics printed: accuracy, precision, recall, F1 (weighted)

## 5) Recommendations (KD-Tree, Brute Force, BM25)
- KD-Tree: built on dense TF-IDF vectors (Euclidean in high-dim as approximation)
- Brute-force: TF-IDF cosine similarity
- BM25: using rank-bm25 (tokenized with NLTK)

Per-query timings for each method are reported in the app UI.

## 6) Streamlit App
- Input text box
- Shows predicted category
- Shows top-10 recommendations from each method with timing

## 7) Deployment / Running

### Install dependencies
```
pip install -r requirements.txt
```

### Train models and indices
```
python train_model.py
```
- Looks for `data/bbc-news-data.csv.zip` (or fallback `data/bbc_dataset.csv`).
- Saves artifacts to `models/`.

### Run the app
```
streamlit run app.py
```
Open the provided local URL in your browser.

## Notes on Timings
- KD-Tree: fastest at query time but uses dense memory; distance is Euclidean (approx to cosine if vectors are normalized).
- Brute force cosine: exact but slower; scales with corpus size.
- BM25: depends on tokenization and corpus stats; independent of TF-IDF.

All timings are measured per-query in milliseconds and displayed in the app, including a consolidated JSON block under the "Debug timings" expander.

