import os
import time
import joblib
import string
import numpy as np
import pandas as pd
from typing import Tuple, List, Dict

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report
from sklearn.neighbors import KDTree
from scipy.sparse import csr_matrix
from scipy.spatial.distance import cdist

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from zipfile import ZipFile

# Ensure NLTK resources
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)

DATA_DIR = os.path.join('data')
MODELS_DIR = os.path.join('models')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

DATASET_ZIP = os.path.join(DATA_DIR, 'bbc-news-data.csv.zip')
DATASET_CSV = os.path.join(DATA_DIR, 'bbc_dataset.csv')  # fallback if provided directly
VECTORIZER_PKL = os.path.join(MODELS_DIR, 'vectorizer.pkl')
CLASSIFIER_PKL = os.path.join(MODELS_DIR, 'classifier.pkl')
KDTREE_PKL = os.path.join(MODELS_DIR, 'kdtree.pkl')
CORPUS_META_PKL = os.path.join(MODELS_DIR, 'corpus_meta.pkl')
BM25_PKL = os.path.join(MODELS_DIR, 'bm25.pkl')
TFIDF_MATRIX_PKL = os.path.join(MODELS_DIR, 'tfidf_matrix.pkl')

try:
	from rank_bm25 import BM25Okapi
	_HAS_BM25 = True
except Exception:
	_HAS_BM25 = False


def _read_csv_flexible(file_obj):
	# Try robust parsing with Python engine and inferred delimiter
	try:
		return pd.read_csv(file_obj, engine='python', sep=None, on_bad_lines='skip')
	except Exception:
		file_obj.seek(0)
		return pd.read_csv(file_obj, engine='python', on_bad_lines='skip')


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
	cols_lower = {c.lower(): c for c in df.columns}
	# Candidate columns
	text_candidates = ['text', 'content', 'article', 'document', 'body']
	title_candidates = ['title', 'headline']
	label_candidates = ['category', 'topic', 'label', 'class']

	text_col = next((cols_lower[c] for c in text_candidates if c in cols_lower), None)
	label_col = next((cols_lower[c] for c in label_candidates if c in cols_lower), None)
	title_col = next((cols_lower[c] for c in title_candidates if c in cols_lower), None)

	if text_col is None and title_col is not None:
		# Some datasets have only title; treat it as text
		df['text'] = df[title_col].astype(str)
		text_col = 'text'
	elif text_col is None:
		raise ValueError('Could not find a text/content column in the dataset')

	if label_col is None:
		raise ValueError('Could not find a category/label column in the dataset')

	if title_col is None:
		df['title'] = ''
		title_col = 'title'

	return df.rename(columns={text_col: 'text', label_col: 'category', title_col: 'title'})[['title','text','category']]


def clean_text(text: str, stop_words: set, lemmatizer: WordNetLemmatizer) -> str:
	if not isinstance(text, str):
		return ''
	text = text.lower()
	text = text.translate(str.maketrans('', '', string.punctuation))
	text = ''.join(ch for ch in text if ch.isalpha() or ch.isspace())
	tokens = nltk.word_tokenize(text)
	tokens = [t for t in tokens if t not in stop_words and len(t) > 2]
	tokens = [lemmatizer.lemmatize(t) for t in tokens]
	return ' '.join(tokens)


def load_dataset() -> pd.DataFrame:
	# Prefer ZIP if present
	if os.path.exists(DATASET_ZIP):
		with ZipFile(DATASET_ZIP) as zf:
			csv_names = [n for n in zf.namelist() if n.lower().endswith('.csv')]
			if not csv_names:
				raise FileNotFoundError(f"No CSV found inside {DATASET_ZIP}")
			csv_name = csv_names[0]
			with zf.open(csv_name) as f:
				df = _read_csv_flexible(f)
	elif os.path.exists(DATASET_CSV):
		with open(DATASET_CSV, 'rb') as f:
			df = _read_csv_flexible(f)
	else:
		raise FileNotFoundError(
			f"Dataset not found. Place 'data/bbc-news-data.csv.zip' (containing a CSV) or 'data/bbc_dataset.csv' with columns ['title','text','category']"
		)

	# Normalize to required columns
	df = _normalize_columns(df).dropna()
	return df


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
	stop_words = set(stopwords.words('english'))
	lemmatizer = WordNetLemmatizer()
	cleaned = df.copy()
	cleaned['clean_text'] = df['text'].apply(lambda t: clean_text(t, stop_words, lemmatizer))
	return cleaned


def vectorize_text(train_texts: List[str], test_texts: List[str]) -> Tuple[TfidfVectorizer, csr_matrix, csr_matrix]:
	vectorizer = TfidfVectorizer(max_features=30000, ngram_range=(1,2), min_df=2)
	X_train = vectorizer.fit_transform(train_texts)
	X_test = vectorizer.transform(test_texts)
	return vectorizer, X_train, X_test


def train_classifier(X_train: csr_matrix, y_train: List[str], algo: str = 'logreg'):
	if algo == 'logreg':
		clf = LogisticRegression(max_iter=2000, n_jobs=None)
	elif algo == 'nb':
		clf = MultinomialNB()
	elif algo == 'svm':
		clf = LinearSVC()
	else:
		raise ValueError('Unknown algo. Use one of: logreg, nb, svm')
	clf.fit(X_train, y_train)
	return clf


def evaluate_classifier(clf, X_test: csr_matrix, y_test: List[str]) -> Dict[str, float]:
	pred = clf.predict(X_test)
	acc = accuracy_score(y_test, pred)
	precision, recall, f1, _ = precision_recall_fscore_support(y_test, pred, average='weighted', zero_division=0)
	return {
		'accuracy': acc,
		'precision': precision,
		'recall': recall,
		'f1': f1,
	}


def build_kdtree(X_all: csr_matrix) -> KDTree:
	# KDTree expects dense arrays; for high-dim TF-IDF this is an approximation
	X_dense = X_all.toarray()
	return KDTree(X_dense, leaf_size=40)


def cosine_top_k(query_vec: csr_matrix, X_all: csr_matrix, k: int = 10) -> Tuple[np.ndarray, np.ndarray]:
	q = query_vec
	norms = np.sqrt((X_all.multiply(X_all)).sum(axis=1)).A1 + 1e-12
	qnorm = np.sqrt((q.multiply(q)).sum(axis=1)).A1 + 1e-12
	sims = (X_all @ q.T).toarray().ravel() / (norms * qnorm)
	idx = np.argsort(-sims)[:k]
	dists = 1 - sims[idx]
	return idx, dists


def build_bm25(corpus_tokens: List[List[str]]):
	if not _HAS_BM25:
		return None
	return BM25Okapi(corpus_tokens)


def tokenize_for_bm25(text: str) -> List[str]:
	return nltk.word_tokenize(text)


def main(classifier_algo: str = 'logreg', test_size: float = 0.2, random_state: int = 42):
	print('Loading dataset...')
	df = load_dataset()
	print(f"Dataset loaded: {len(df)} rows")

	print('Preprocessing...')
	df_clean = preprocess(df)

	print('Splitting train/test...')
	X_train_text, X_test_text, y_train, y_test = train_test_split(
		df_clean['clean_text'].tolist(), df_clean['category'].tolist(),
		test_size=test_size, random_state=random_state, stratify=df_clean['category']
	)

	print('Vectorizing TF-IDF...')
	vectorizer, X_train, X_test = vectorize_text(X_train_text, X_test_text)

	print('Training classifier...')
	clf = train_classifier(X_train, y_train, algo=classifier_algo)
	metrics = evaluate_classifier(clf, X_test, y_test)
	print('Evaluation:', metrics)

	# Build full corpus matrix for recommendations
	print('Vectorizing full corpus...')
	X_all = vectorizer.transform(df_clean['clean_text'])

	print('Building KD-Tree (on dense TF-IDF)...')
	kdtree = build_kdtree(X_all)

	print('Building BM25 index...')
	bm25 = build_bm25([tokenize_for_bm25(t) for t in df_clean['clean_text']])

	print('Persisting artifacts...')
	joblib.dump(vectorizer, VECTORIZER_PKL)
	joblib.dump(clf, CLASSIFIER_PKL)
	joblib.dump(kdtree, KDTREE_PKL)
	joblib.dump({'titles': df['title'].tolist(), 'categories': df['category'].tolist(), 'texts': df['text'].tolist()}, CORPUS_META_PKL)
	joblib.dump(X_all, TFIDF_MATRIX_PKL)
	if bm25 is not None:
		joblib.dump(bm25, BM25_PKL)

	print('Done.')
	print('Artifacts saved to models/.')

if __name__ == '__main__':
	main()
