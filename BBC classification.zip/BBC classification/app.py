import os
import time
import joblib
import numpy as np
import streamlit as st
import nltk
from typing import List, Tuple
from sklearn.neighbors import KDTree
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import csr_matrix
import pandas as pd

# Ensure tokenizer available for BM25
try:
	nltk.data.find('tokenizers/punkt')
except LookupError:
	nltk.download('punkt', quiet=True)

st.set_page_config(page_title='BBC News Classification & Recommendations', layout='wide')

MODELS_DIR = 'models'
VECTORIZER_PKL = os.path.join(MODELS_DIR, 'vectorizer.pkl')
CLASSIFIER_PKL = os.path.join(MODELS_DIR, 'classifier.pkl')
KDTREE_PKL = os.path.join(MODELS_DIR, 'kdtree.pkl')
CORPUS_META_PKL = os.path.join(MODELS_DIR, 'corpus_meta.pkl')
BM25_PKL = os.path.join(MODELS_DIR, 'bm25.pkl')
TFIDF_MATRIX_PKL = os.path.join(MODELS_DIR, 'tfidf_matrix.pkl')

@st.cache_resource(show_spinner=False)
def load_artifacts():
	vectorizer: TfidfVectorizer = joblib.load(VECTORIZER_PKL)
	classifier = joblib.load(CLASSIFIER_PKL)
	kdtree: KDTree = joblib.load(KDTREE_PKL)
	corpus_meta = joblib.load(CORPUS_META_PKL)
	X_all: csr_matrix = joblib.load(TFIDF_MATRIX_PKL)
	bm25 = None
	if os.path.exists(BM25_PKL):
		try:
			bm25 = joblib.load(BM25_PKL)
		except Exception:
			bm25 = None
	return vectorizer, classifier, kdtree, corpus_meta, bm25, X_all


def brute_force_cosine(query_vec: csr_matrix, X_all: csr_matrix, k: int = 10):
	norms = np.sqrt((X_all.multiply(X_all)).sum(axis=1)).A1 + 1e-12
	qnorm = np.sqrt((query_vec.multiply(query_vec)).sum(axis=1)).A1 + 1e-12
	sims = (X_all @ query_vec.T).toarray().ravel() / (norms * qnorm)
	idx = np.argsort(-sims)[:k]
	return idx, sims[idx]


def kdtree_query(query_vec: csr_matrix, kdtree: KDTree, X_all: csr_matrix, k: int = 10):
	q_dense = query_vec.toarray()
	dists, inds = kdtree.query(q_dense, k=k)
	return inds[0], 1 - dists[0]


def bm25_query(bm25, text: str, k: int = 10):
	if bm25 is None:
		return np.array([], dtype=int), np.array([])
	tokens = nltk.word_tokenize(text)
	scores = np.array(bm25.get_scores(tokens))
	idx = np.argsort(-scores)[:k]
	return idx, scores[idx]


def cosine_between(q: csr_matrix, d: csr_matrix) -> float:
	qd = (d @ q.T).toarray().ravel()[0]
	qnorm = np.sqrt((q.multiply(q)).sum()) + 1e-12
	dnorm = np.sqrt((d.multiply(d)).sum()) + 1e-12
	return float(qd / (qnorm * dnorm))


def top_terms(vec: csr_matrix, vectorizer: TfidfVectorizer, top_n: int = 8):
	row = vec.tocoo()
	pairs = list(zip(row.col, row.data))
	pairs.sort(key=lambda x: -x[1])
	feature_names = np.array(vectorizer.get_feature_names_out())
	terms = []
	for idx, val in pairs[:top_n]:
		terms.append((feature_names[idx], float(val)))
	return terms


def format_results(indices: np.ndarray, scores: np.ndarray, corpus_meta, top_k: int = 10):
	results = []
	for rank, (i, s) in enumerate(zip(indices[:top_k], scores[:top_k]), start=1):
		results.append({
			'rank': rank,
			'idx': int(i),
			'title': corpus_meta['titles'][i] if corpus_meta['titles'][i] else f'Article {i}',
			'category': corpus_meta['categories'][i],
			'score': float(s)
		})
	return results


def main():
	st.title('BBC News Text Classification and Recommendations')
	st.write('TF-IDF + Classifier with KD-Tree, Brute-force Cosine, and BM25 recommendations (top 10).')

	if not (os.path.exists(VECTORIZER_PKL) and os.path.exists(CLASSIFIER_PKL) and os.path.exists(KDTREE_PKL) and os.path.exists(CORPUS_META_PKL) and os.path.exists(TFIDF_MATRIX_PKL)):
		st.warning('Models not found. Please run: python train_model.py')
		return

	vectorizer, classifier, kdtree, corpus_meta, bm25, X_all = load_artifacts()

	with st.sidebar:
		st.header('Input')
		default_text = 'UK technology company reports record profits as markets rally and investors anticipate interest rate cuts.'
		user_text = st.text_area('Enter article text', value=default_text, height=200)
		top_k = st.slider('Top K recommendations', min_value=5, max_value=20, value=10, step=1)
		rec_method = st.selectbox('Vector database (recommender)', options=['All','KD-Tree','Brute-force Cosine','BM25 (bestmatch25)'])
		show_weights = st.checkbox('Show top TF-IDF terms per result', value=True)
		go = st.button('Analyze')

	if not go:
		st.info('Enter text and click Analyze to get predictions and recommendations.')
		return

	# Predict category
	start_pred = time.perf_counter()
	q_vec = vectorizer.transform([user_text])
	pred_category = classifier.predict(q_vec)[0]
	pred_time_ms = (time.perf_counter() - start_pred) * 1000

	st.subheader('Predicted Category')
	st.markdown(f"**{pred_category}**  ")
	st.caption(f"Prediction time: {pred_time_ms:.2f} ms")

	# Run recommenders according to selection
	kd_results = []
	br_results = []
	bm_results = []
	kd_time_ms = br_time_ms = bm_time_ms = 0.0

	if rec_method in ('All','KD-Tree'):
		start_kd = time.perf_counter()
		kd_idx, kd_scores = kdtree_query(q_vec, kdtree, X_all, k=top_k)
		kd_time_ms = (time.perf_counter() - start_kd) * 1000
		kd_results = format_results(kd_idx, kd_scores, corpus_meta, top_k)
		# add cosine similarity column
		for r in kd_results:
			doc_vec = X_all[r['idx']]
			r['cosine'] = cosine_between(q_vec, doc_vec)

	if rec_method in ('All','Brute-force Cosine'):
		start_br = time.perf_counter()
		br_idx, br_scores = brute_force_cosine(q_vec, X_all, k=top_k)
		br_time_ms = (time.perf_counter() - start_br) * 1000
		br_results = format_results(br_idx, br_scores, corpus_meta, top_k)
		for r in br_results:
			r['cosine'] = float(r['score'])

	if rec_method in ('All','BM25 (bestmatch25)'):
		start_bm = time.perf_counter()
		bm_idx, bm_scores = bm25_query(bm25, user_text, k=top_k)
		bm_time_ms = (time.perf_counter() - start_bm) * 1000
		bm_results = format_results(bm_idx, bm_scores, corpus_meta, top_k)
		for r in bm_results:
			# Compute cosine similarity between query TF-IDF and the BM25-picked doc TF-IDF
			doc_vec = X_all[r['idx']]
			r['cosine'] = cosine_between(q_vec, doc_vec)

	# Precompute query top terms
	query_terms = top_terms(q_vec, vectorizer, top_n=8)

	# Layout
	if rec_method == 'All':
		col1, col2, col3 = st.columns(3)
	else:
		col1 = st.container()
		col2 = st.container()
		col3 = st.container()

	def render_block(container, title, results, t_ms):
		with container:
			st.subheader(title)
			st.caption(f"Query time: {t_ms:.2f} ms")
			if len(results) == 0:
				st.info('No results available for this method.')
				return
			for r in results:
				st.markdown(f"{r['rank']}. **{r['title']}** — _{r['category']}_  ")
				st.caption(f"Similarity (method score): {r['score']:.4f} | Cosine(TF-IDF): {r['cosine']:.4f}")
				if show_weights:
					with st.expander('View term weights'):
						doc_vec = X_all[r['idx']]
						doc_terms = top_terms(doc_vec, vectorizer, top_n=8)
						col_q, col_d = st.columns(2)
						with col_q:
							st.markdown('Query top TF-IDF terms')
							st.table(pd.DataFrame(query_terms, columns=['term','tfidf']))
						with col_d:
							st.markdown('Document top TF-IDF terms')
							st.table(pd.DataFrame(doc_terms, columns=['term','tfidf']))

			# Visualizations for the whole block
			df_scores = pd.DataFrame({'Title':[r['title'] for r in results],'Score':[r['score'] for r in results],'Cosine':[r['cosine'] for r in results],'Category':[r['category'] for r in results]})
			st.markdown('Top-K scores')
			st.bar_chart(df_scores.set_index('Title')[['Score','Cosine']])
			st.markdown('Category distribution in top-K')
			st.bar_chart(df_scores['Category'].value_counts())

	if rec_method in ('All','KD-Tree'):
		render_block(col1, 'KD-Tree (TF-IDF, Euclidean approx)', kd_results, kd_time_ms)
	if rec_method in ('All','Brute-force Cosine'):
		render_block(col2, 'Brute-force (TF-IDF, Cosine)', br_results, br_time_ms)
	if rec_method in ('All','BM25 (bestmatch25)'):
		render_block(col3, 'BM25 (bestmatch25)', bm_results, bm_time_ms)

	# Timings visualization
	timing_rows = []
	if rec_method in ('All','KD-Tree'):
		timing_rows.append(('KD-Tree', kd_time_ms))
	if rec_method in ('All','Brute-force Cosine'):
		timing_rows.append(('Brute-force Cosine', br_time_ms))
	if rec_method in ('All','BM25 (bestmatch25)'):
		timing_rows.append(('BM25', bm_time_ms))
	if timing_rows:
		st.subheader('Per-method query times (ms)')
		df_t = pd.DataFrame(timing_rows, columns=['Method','ms']).set_index('Method')
		st.bar_chart(df_t)

	with st.expander('Debug timings (ms)'):
		st.json({
			'prediction_ms': round(pred_time_ms, 2),
			'kdtree_query_ms': round(kd_time_ms, 2),
			'bruteforce_cosine_ms': round(br_time_ms, 2),
			'bm25_query_ms': round(bm_time_ms, 2),
		})

if __name__ == '__main__':
	main()
