import os
import io
import base64
import json
from datetime import datetime, timedelta

from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash

# ML imports
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import joblib

# Visualization imports
import matplotlib
matplotlib.use("Agg")  # Non-GUI backend for servers
import matplotlib.pyplot as plt
import seaborn as sns


def create_app():
    app = Flask(__name__, instance_relative_config=True, static_folder="static", template_folder="templates")

    # Ensure instance folder exists
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    # Secret key for sessions
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

    # Database configuration
    db_path = os.path.join(app.instance_path, "app.db")
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_path}"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    with app.app_context():
        db.create_all()

    # Prepare model assets
    model_path = os.path.join(app.root_path, "house_price_model.pkl")
    scaler_path = os.path.join(app.root_path, "scaler.pkl")
    ensure_model_and_scaler(model_path, scaler_path)

    # Preload model and scaler
    app.model = joblib.load(model_path)
    app.scaler = joblib.load(scaler_path)

    # Ensure plots directory exists
    os.makedirs(os.path.join(app.static_folder, "plots"), exist_ok=True)

    # Routes
    @app.route("/")
    def index():
        return render_template("index.html", user=current_user())

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")

            if not username or not email or not password:
                flash("All fields are required.", "error")
                return redirect(url_for("register"))

            if User.query.filter((User.username == username) | (User.email == email)).first():
                flash("Username or email already exists.", "error")
                return redirect(url_for("register"))

            password_hash = generate_password_hash(password)
            user = User(username=username, email=email, password_hash=password_hash)
            db.session.add(user)
            db.session.commit()

            log_action(user_id=user.id, action_type="register", details={"username": username, "email": email})

            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")

            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password_hash, password):
                session["user_id"] = user.id
                user.last_login_at = datetime.utcnow()
                db.session.commit()
                log_action(user_id=user.id, action_type="login", details={"username": username})
                flash("Logged in successfully.", "success")
                next_url = request.args.get("next")
                return redirect(next_url or url_for("dashboard"))
            else:
                log_action(user_id=user.id if user else None, action_type="login_failed", details={"username": username})
                flash("Invalid username or password.", "error")
                return redirect(url_for("login"))
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        uid = session.pop("user_id", None)
        log_action(user_id=uid, action_type="logout", details={})
        flash("You have been logged out.", "info")
        return redirect(url_for("index"))

    @app.route("/predict", methods=["GET", "POST"])
    @login_required
    def predict():
        feature_names = get_feature_names()
        if request.method == "POST":
            try:
                inputs = [float(request.form.get(name, 0.0)) for name in feature_names]
            except ValueError:
                flash("Please enter valid numeric values.", "error")
                return redirect(url_for("predict"))

            x = np.array(inputs, dtype=float).reshape(1, -1)
            x_scaled = current_app().scaler.transform(x)
            proba = float(current_app().model.predict_proba(x_scaled)[0][1])
            label = int(proba >= 0.5)

            # Store prediction
            user = current_user()
            pred = Prediction(
                user_id=user.id,
                input_json=json.dumps(dict(zip(feature_names, inputs))),
                output_value=proba,
                output_label=label,
            )
            db.session.add(pred)
            db.session.commit()

            log_action(user_id=user.id, action_type="predict", details={"prediction_id": pred.id, "proba": proba, "label": label})

            return redirect(url_for("result", id=pred.id))

        return render_template("predict.html", feature_names=feature_names, user=current_user())

    @app.route("/result")
    @login_required
    def result():
        pred_id = request.args.get("id", type=int)
        if not pred_id:
            flash("No prediction to show.", "info")
            return redirect(url_for("predict"))
        pred = Prediction.query.filter_by(id=pred_id, user_id=current_user().id).first()
        if not pred:
            abort(404)
        data = json.loads(pred.input_json)
        return render_template("prediction_result.html", prediction=pred, inputs=data, user=current_user())

    @app.route("/dashboard")
    @login_required
    def dashboard():
        user = current_user()

        # Summary stats
        total_preds = Prediction.query.count()
        user_preds = Prediction.query.filter_by(user_id=user.id).count()
        avg_proba = db.session.query(func.avg(Prediction.output_value)).scalar() or 0.0
        user_avg_proba = db.session.query(func.avg(Prediction.output_value)).filter(Prediction.user_id == user.id).scalar() or 0.0

        # Charts as base64 images
        charts = {}
        charts["proba_distribution_all"] = plot_distribution(
            values=[p.output_value for p in Prediction.query.all()],
            title="Distribution of Predicted Malignancy Probability (All)",
        )
        charts["proba_distribution_user"] = plot_distribution(
            values=[p.output_value for p in Prediction.query.filter_by(user_id=user.id).all()],
            title="Your Predictions Probability Distribution",
            color="#2a9d8f",
        )
        charts["preds_per_user"] = plot_counts_per_user()
        charts["trend_over_time"] = plot_trend_over_time(user_only=False)

        return render_template(
            "dashboard.html",
            user=user,
            total_preds=total_preds,
            user_preds=user_preds,
            avg_proba=avg_proba,
            user_avg_proba=user_avg_proba,
            charts=charts,
        )

    @app.route("/history")
    @login_required
    def history():
        user = current_user()
        # Filters
        days = request.args.get("days", type=int)
        q = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.desc())
        if days:
            since = datetime.utcnow() - timedelta(days=days)
            q = q.filter(Prediction.created_at >= since)
        preds = q.all()
        return render_template("history.html", user=user, predictions=preds, days=days)

    return app


# Database setup
db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login_at = db.Column(db.DateTime)


class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    input_json = db.Column(db.Text, nullable=False)
    output_value = db.Column(db.Float, nullable=False)  # probability of malignant
    output_label = db.Column(db.Integer, nullable=False)  # 1 malignant, 0 benign
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship("User", backref=db.backref("predictions", lazy=True))


class ActionLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    action_type = db.Column(db.String(50), nullable=False)
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship("User", backref=db.backref("actions", lazy=True))


# Helpers
def current_app():
    from flask import current_app as _current_app
    return _current_app


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return User.query.get(uid)


def login_required(view):
    from functools import wraps

    @wraps(view)
    def wrapped_view(**kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return view(**kwargs)
    return wrapped_view


def log_action(user_id, action_type, details):
    try:
        entry = ActionLog(user_id=user_id, action_type=action_type, details=json.dumps(details))
        db.session.add(entry)
        db.session.commit()
    except Exception:
        db.session.rollback()


def get_feature_names():
    # Use 5 informative features for a concise form
    return [
        "mean_radius",
        "mean_texture",
        "mean_perimeter",
        "mean_area",
        "mean_smoothness",
    ]


def ensure_model_and_scaler(model_path, scaler_path):
    """Train a simple classifier on sklearn breast cancer dataset if assets are missing."""
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        return

    data = load_breast_cancer()
    # Map our selected features to dataset indices
    feature_indices = [
        list(data.feature_names).index("mean radius"),
        list(data.feature_names).index("mean texture"),
        list(data.feature_names).index("mean perimeter"),
        list(data.feature_names).index("mean area"),
        list(data.feature_names).index("mean smoothness"),
    ]
    X = data.data[:, feature_indices]
    y = data.target  # 0 = malignant, 1 = benign in sklearn dataset

    # We want probability of malignant as positive class. In dataset, malignant=0.
    # Flip labels so malignant=1, benign=0 for intuitive probability.
    y_flipped = (y == 0).astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y_flipped, test_size=0.2, random_state=42, stratify=y_flipped)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    model = LogisticRegression(max_iter=200, random_state=42)
    model.fit(X_train_scaled, y_train)

    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)


def fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("ascii")


def plot_distribution(values, title, color="#1f77b4"):
    if not values:
        return None
    fig, ax = plt.subplots(figsize=(5, 3))
    sns.histplot(values, bins=20, kde=True, color=color, ax=ax)
    ax.set_title(title)
    ax.set_xlabel("Probability (malignant)")
    ax.set_ylabel("Count")
    return fig_to_base64(fig)


def plot_counts_per_user():
    rows = db.session.query(User.username, func.count(Prediction.id)).join(Prediction, isouter=True).group_by(User.id).all()
    if not rows:
        return None
    usernames = [r[0] for r in rows]
    counts = [int(r[1]) for r in rows]
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.bar(usernames, counts, color="#264653")
    ax.set_title("Predictions per User")
    ax.set_ylabel("Count")
    ax.set_xticklabels(usernames, rotation=30, ha="right")
    return fig_to_base64(fig)


def plot_trend_over_time(user_only=False):
    q = Prediction.query
    if user_only and current_user():
        q = q.filter(Prediction.user_id == current_user().id)
    rows = q.with_entities(func.date(Prediction.created_at), func.count(Prediction.id)).group_by(func.date(Prediction.created_at)).order_by(func.date(Prediction.created_at)).all()
    if not rows:
        return None
    dates = [str(r[0]) for r in rows]
    counts = [int(r[1]) for r in rows]
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.plot(dates, counts, marker="o", color="#e76f51")
    ax.set_title("Predictions Over Time")
    ax.set_ylabel("Count")
    ax.set_xlabel("Date")
    ax.grid(True, alpha=0.3)
    ax.set_xticklabels(dates, rotation=45, ha="right")
    return fig_to_base64(fig)


if __name__ == "__main__":
    app = create_app()
    # For local dev on Windows, enable reloader and debug
    app.run(host="127.0.0.1", port=5000, debug=True)


