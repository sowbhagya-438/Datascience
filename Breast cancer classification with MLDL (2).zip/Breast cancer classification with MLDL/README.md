Breast Cancer Classification (Flask)

A Flask web app for predicting breast cancer malignancy probability using a trained model (sklearn breast cancer dataset). Includes authentication, prediction history, and dashboards with charts.

Features
- User registration/login with hashed passwords (SQLite)
- Prediction form with 5 core features
- Stores each prediction with inputs/output and timestamp
- Dashboard: distributions, counts per user, trends over time
- History page with date filters and detail views
- Action tracking for register, login, logout, predict

Quick Start

1) Create virtual environment
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
```

2) Install dependencies
```bash
pip install -r requirements.txt
```

3) Run the app
```bash
python app.py
```
Open http://127.0.0.1:5000

Notes
- On first run, if `house_price_model.pkl` and `scaler.pkl` are missing, a logistic regression model is trained on 5 selected features and saved.
- SQLite database is stored under `instance/app.db`.
- All pages extend `templates/base.html`. Styles in `static/style.css`.

Routes
- `/` Home
- `/register` Register
- `/login` Login
- `/logout` Logout
- `/predict` Prediction form (auth required)
- `/result?id=<prediction_id>` Prediction result (auth required)
- `/dashboard` Dashboard (auth required)
- `/history` History with optional `?days=7|30|90` (auth required)

Environment
- `SECRET_KEY` optional env var for session signing


