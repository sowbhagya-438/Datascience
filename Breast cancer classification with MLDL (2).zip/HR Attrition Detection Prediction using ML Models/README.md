# HR Attrition Prediction Flask App

A Flask web app that predicts employee attrition probability. Includes authentication, SQLite storage, prediction history, and a dashboard with charts.

## Features
- User registration/login (password hashing)
- Predict attrition probability with a simple form
- Save predictions per user with timestamp
- Dashboard: summary stats and charts (matplotlib)
- History: filterable list of past predictions
- Action logging for register/login/predict/logout

## Tech
- Flask, Flask-SQLAlchemy, SQLite
- scikit-learn, numpy, matplotlib

## Setup
1. Create virtual environment and install deps
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell
pip install -r requirements.txt
```

2. Run the app
```bash
python app.py
```

The app creates the SQLite database in `instance/app.sqlite` on first run.

## Notes on the Model
- If `house_price_model.pkl` and `scaler.pkl` exist, the app will attempt to load them.
- Otherwise it trains a simple Logistic Regression on synthetic HR-like features for demo purposes.

## Environment
- `SECRET_KEY` optional; defaults to a development key.
- `PORT` optional; defaults to 5000.

## Routes
- `/` Home
- `/register` Register
- `/login` Login
- `/logout` Logout
- `/predict` Prediction form (auth required)
- `/result` Result is rendered directly after prediction
- `/dashboard` Dashboard (auth required)
- `/history` History (auth required)

## Security
This demo is for educational purposes. Do not use in production without proper hardening.

