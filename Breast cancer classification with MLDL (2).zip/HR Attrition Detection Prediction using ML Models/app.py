import os
import io
import json
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import numpy as np
import pandas as pd
import pickle
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


db = SQLAlchemy()


def create_app():
    app = Flask(__name__, instance_relative_config=True)

    # Config
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key")
    db_path = os.path.join(app.instance_path, "app.sqlite")
    os.makedirs(app.instance_path, exist_ok=True)
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_path}"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    # Models
    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        username = db.Column(db.String(80), unique=True, nullable=False)
        email = db.Column(db.String(120), unique=True, nullable=False)
        password_hash = db.Column(db.String(255), nullable=False)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)

        predictions = db.relationship("Prediction", backref="user", lazy=True)

        def set_password(self, password: str) -> None:
            self.password_hash = generate_password_hash(password)

        def check_password(self, password: str) -> bool:
            return check_password_hash(self.password_hash, password)

    class Prediction(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
        # Store inputs as JSON for flexibility
        inputs_json = db.Column(db.Text, nullable=False)
        prediction_value = db.Column(db.Float, nullable=False)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)

    class ActionLog(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
        action = db.Column(db.String(64), nullable=False)  # register, login, predict, logout
        info = db.Column(db.Text, nullable=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)

    with app.app_context():
        db.create_all()

    # Utilities
    def log_action(action: str, user_id: int | None, info: dict | None = None) -> None:
        entry = ActionLog(action=action, user_id=user_id, info=json.dumps(info or {}))
        db.session.add(entry)
        db.session.commit()

    def current_user():
        uid = session.get("user_id")
        if not uid:
            return None
        return User.query.get(uid)

    def login_required(view_func):
        from functools import wraps

        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("login"))
            return view_func(*args, **kwargs)

        return wrapped

    # Model loading or fallback training for HR Attrition
    MODEL_PATH = os.path.join(app.root_path, "house_price_model.pkl")
    SCALER_PATH = os.path.join(app.root_path, "scaler.pkl")

    def load_or_train_model():
        # For this HR Attrition app, if provided pickles exist we use them; otherwise train a simple model on sample attrition data.
        model = None
        scaler = None
        if os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH):
            try:
                with open(MODEL_PATH, "rb") as f:
                    model = pickle.load(f)
                with open(SCALER_PATH, "rb") as f:
                    scaler = pickle.load(f)
            except Exception:
                model = None
                scaler = None

        if model is None or scaler is None:
            from sklearn.preprocessing import StandardScaler
            from sklearn.linear_model import LogisticRegression
            from sklearn.model_selection import train_test_split

            # Create a tiny synthetic HR Attrition dataset
            rng = np.random.default_rng(42)
            n = 400
            age = rng.integers(18, 60, size=n)
            years_at_company = rng.integers(0, 30, size=n)
            monthly_income = rng.normal(6000, 2000, size=n).clip(2000, 20000)
            job_satisfaction = rng.integers(1, 5, size=n)
            overtime = rng.integers(0, 2, size=n)  # 0/1

            # Simple rule-based target with noise
            logits = (
                -3.0
                + 0.03 * (30 - years_at_company)
                + 0.0002 * (8000 - monthly_income)
                + 0.3 * (3 - job_satisfaction)
                + 0.6 * overtime
            )
            prob = 1 / (1 + np.exp(-logits))
            attrition = (rng.random(n) < prob).astype(int)

            X = np.column_stack(
                [age, years_at_company, monthly_income, job_satisfaction, overtime]
            )
            y = attrition

            scaler = StandardScaler()
            Xs = scaler.fit_transform(X)
            model = LogisticRegression(max_iter=1000)
            model.fit(Xs, y)

        return model, scaler

    model, scaler = load_or_train_model()

    # Routes
    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            confirm = request.form.get("confirm", "")

            if not username or not email or not password:
                flash("All fields are required.", "danger")
                return redirect(url_for("register"))
            if password != confirm:
                flash("Passwords do not match.", "danger")
                return redirect(url_for("register"))
            if User.query.filter((User.username == username) | (User.email == email)).first():
                flash("User already exists.", "warning")
                return redirect(url_for("register"))

            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            log_action("register", user.id, {"username": username})
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))

        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                session["user_id"] = user.id
                log_action("login", user.id, {"username": username})
                flash("Logged in successfully.", "success")
                return redirect(url_for("dashboard"))
            flash("Invalid credentials.", "danger")
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        uid = session.pop("user_id", None)
        log_action("logout", uid, {})
        flash("You have been logged out.", "info")
        return redirect(url_for("index"))

    @app.route("/predict", methods=["GET", "POST"])
    @login_required
    def predict():
        if request.method == "POST":
            try:
                # Collect HR attrition features
                age = float(request.form.get("age", 0))
                years_at_company = float(request.form.get("years_at_company", 0))
                monthly_income = float(request.form.get("monthly_income", 0))
                job_satisfaction = float(request.form.get("job_satisfaction", 1))
                overtime = 1.0 if request.form.get("overtime") == "on" else 0.0

                features = np.array(
                    [[age, years_at_company, monthly_income, job_satisfaction, overtime]]
                )
                features_scaled = scaler.transform(features)
                proba = float(getattr(model, "predict_proba")(features_scaled)[0, 1])
                pred_label = int(proba >= 0.5)

                inputs = {
                    "age": age,
                    "years_at_company": years_at_company,
                    "monthly_income": monthly_income,
                    "job_satisfaction": job_satisfaction,
                    "overtime": int(overtime),
                }

                pred = Prediction(
                    user_id=session["user_id"],
                    inputs_json=json.dumps(inputs),
                    prediction_value=proba,
                )
                db.session.add(pred)
                db.session.commit()
                log_action("predict", session["user_id"], {"prediction_id": pred.id})

                return render_template(
                    "prediction_result.html",
                    probability=proba,
                    label=pred_label,
                    inputs=inputs,
                )
            except Exception as e:
                flash(f"Prediction failed: {e}", "danger")
                return redirect(url_for("predict"))

        return render_template("predict.html")

    @app.route("/dashboard")
    @login_required
    def dashboard():
        uid = session["user_id"]
        # Fetch user's predictions
        preds = Prediction.query.filter_by(user_id=uid).order_by(Prediction.created_at).all()

        # Summary
        total = len(preds)
        avg_prob = float(np.mean([p.prediction_value for p in preds])) if preds else 0.0
        high_risk = sum(1 for p in preds if p.prediction_value >= 0.5)

        # Visualization: distribution of probabilities
        fig, ax = plt.subplots(figsize=(5, 3))
        if preds:
            ax.hist([p.prediction_value for p in preds], bins=10, color="#4e79a7")
        else:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
        ax.set_title("Predicted Attrition Probability Distribution")
        ax.set_xlabel("Probability")
        ax.set_ylabel("Count")
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format="png")
        plt.close(fig)
        buf.seek(0)
        dist_png = base64_encode(buf.read())

        # Predictions over time
        times = [p.created_at for p in preds]
        values = [p.prediction_value for p in preds]
        fig2, ax2 = plt.subplots(figsize=(5, 3))
        if preds:
            ax2.plot(times, values, marker="o")
        else:
            ax2.text(0.5, 0.5, "No data", ha="center", va="center")
        ax2.set_title("Prediction Probability Over Time")
        ax2.set_xlabel("Time")
        ax2.set_ylabel("Probability")
        buf2 = io.BytesIO()
        fig2.tight_layout()
        fig2.savefig(buf2, format="png")
        plt.close(fig2)
        buf2.seek(0)
        trend_png = base64_encode(buf2.read())

        # Activity counts (predictions per user just for this user)
        actions = ActionLog.query.filter_by(user_id=uid).all()
        actions_count = len(actions)

        return render_template(
            "dashboard.html",
            total_predictions=total,
            average_probability=avg_prob,
            high_risk_count=high_risk,
            dist_png=dist_png,
            trend_png=trend_png,
            actions_count=actions_count,
        )

    def base64_encode(data: bytes) -> str:
        import base64

        return base64.b64encode(data).decode("ascii")

    @app.route("/history")
    @login_required
    def history():
        uid = session["user_id"]
        # Optional filters
        start = request.args.get("start")
        end = request.args.get("end")
        q = Prediction.query.filter_by(user_id=uid)
        if start:
            try:
                dt = datetime.fromisoformat(start)
                q = q.filter(Prediction.created_at >= dt)
            except Exception:
                pass
        if end:
            try:
                dt = datetime.fromisoformat(end)
                q = q.filter(Prediction.created_at <= dt)
            except Exception:
                pass
        preds = q.order_by(Prediction.created_at.desc()).all()
        rows = [
            {
                "id": p.id,
                "created_at": p.created_at,
                "probability": p.prediction_value,
                "label": int(p.prediction_value >= 0.5),
                "inputs": json.loads(p.inputs_json),
            }
            for p in preds
        ]
        return render_template("history.html", rows=rows)

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)


