from flask import Flask, render_template, redirect, url_for, request, flash, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import uuid
from collections import Counter, defaultdict

try:
    import plotly.express as px
    from plotly.offline import plot as plotly_plot
except Exception:
    px = None
    plotly_plot = None

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}

# Initialize Flask app
app = Flask(__name__, instance_relative_config=True)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(app.instance_path, 'app.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.instance_path, 'uploads')

# Ensure instance subfolders exist
os.makedirs(app.instance_path, exist_ok=True)
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    predictions = db.relationship('Prediction', backref='user', lazy=True)
    events = db.relationship('EventLog', backref='user', lazy=True)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    image_filename = db.Column(db.String(255), nullable=False)
    predicted_label = db.Column(db.String(120), nullable=False)
    estimated_calories = db.Column(db.Float, nullable=False)
    extra_metadata = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class EventLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    event_type = db.Column(db.String(50), nullable=False)  # register, login, predict
    details = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def dummy_food_model_predict(image_path: str) -> tuple[str, float]:
    # Simple placeholder: classify based on filename keywords; otherwise randomish mapping
    basename = os.path.basename(image_path).lower()
    label_to_calories = {
        'apple': 95,
        'banana': 105,
        'pizza': 285,
        'burger': 354,
        'salad': 152,
        'rice': 206,
        'pasta': 221,
        'sushi': 200,
        'donut': 195,
        'cake': 235,
    }
    for key, cals in label_to_calories.items():
        if key in basename:
            return key.title(), float(cals)
    # Fallback default
    return 'Food Item', 200.0


# Routes
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))

        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or email already exists.', 'danger')
            return redirect(url_for('register'))

        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        db.session.add(EventLog(user_id=user.id, event_type='register', details={'username': username, 'email': email}))
        db.session.commit()

        flash('Registration successful. Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            db.session.add(EventLog(user_id=user.id, event_type='login', details={'username': username}))
            db.session.commit()
            flash('Logged in successfully.', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid credentials.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


@app.route('/uploads/<path:filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    if request.method == 'POST':
        file = request.files.get('image')
        if not file or file.filename == '':
            flash('Please select an image file.', 'danger')
            return redirect(url_for('predict'))
        if not allowed_file(file.filename):
            flash('Unsupported file type. Allowed: png, jpg, jpeg, gif.', 'danger')
            return redirect(url_for('predict'))

        filename = secure_filename(file.filename)
        unique_name = f"{uuid.uuid4().hex}_{filename}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
        file.save(save_path)

        label, calories = dummy_food_model_predict(save_path)

        prediction = Prediction(
            user_id=current_user.id,
            image_filename=unique_name,
            predicted_label=label,
            estimated_calories=calories,
            extra_metadata={'source': 'dummy'}
        )
        db.session.add(prediction)
        db.session.commit()

        db.session.add(EventLog(user_id=current_user.id, event_type='predict', details={'label': label, 'calories': calories}))
        db.session.commit()

        return redirect(url_for('result', prediction_id=prediction.id))
    return render_template('predict.html')


@app.route('/result/<int:prediction_id>')
@login_required
def result(prediction_id: int):
    prediction = Prediction.query.filter_by(id=prediction_id, user_id=current_user.id).first_or_404()
    return render_template('prediction_result.html', prediction=prediction)


@app.route('/dashboard')
@login_required
def dashboard():
    # Gather data
    all_predictions = Prediction.query.order_by(Prediction.created_at.asc()).all()
    user_predictions = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.asc()).all()

    # Summary stats
    total_preds = len(all_predictions)
    user_preds = len(user_predictions)

    dist_html = None
    trend_html = None
    user_html = None

    if px and plotly_plot and total_preds > 0:
        # Calorie distribution (all predictions)
        dist_fig = px.histogram(
            x=[p.estimated_calories for p in all_predictions],
            nbins=20,
            labels={'x': 'Estimated Calories (kcal)'},
            title='Calorie Distribution (All Users)'
        )
        dist_fig.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=350)
        dist_html = plotly_plot(dist_fig, include_plotlyjs='cdn', output_type='div')

        # Predictions over time (current user)
        dates = [p.created_at for p in user_predictions]
        cum_counts = list(range(1, len(dates)+1))
        if len(dates) > 0:
            trend_fig = px.line(x=dates, y=cum_counts, labels={'x': 'Time', 'y': 'Cumulative Predictions'}, title='Your Predictions Over Time')
            trend_fig.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=350)
            trend_html = plotly_plot(trend_fig, include_plotlyjs='cdn', output_type='div')

        # Predictions per user (top 10)
        counts_by_user = Counter([p.user_id for p in all_predictions])
        if counts_by_user:
            user_ids = list(counts_by_user.keys())
            counts = [counts_by_user[uid] for uid in user_ids]
            usernames = {u.id: u.username for u in User.query.filter(User.id.in_(user_ids)).all()}
            labels = [usernames.get(uid, str(uid)) for uid in user_ids]
            user_fig = px.bar(x=labels, y=counts, labels={'x': 'User', 'y': 'Predictions'}, title='Predictions by User')
            user_fig.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=350)
            user_html = plotly_plot(user_fig, include_plotlyjs='cdn', output_type='div')

    return render_template('dashboard.html', dist_html=dist_html, trend_html=trend_html, user_html=user_html, total_preds=total_preds, user_preds=user_preds)


@app.route('/history', methods=['GET', 'POST'])
@login_required
def history():
    label_filter = request.values.get('label', '').strip()
    start_date_str = request.values.get('start_date', '').strip()
    end_date_str = request.values.get('end_date', '').strip()

    query = Prediction.query.filter_by(user_id=current_user.id)

    if label_filter:
        query = query.filter(Prediction.predicted_label.ilike(f"%{label_filter}%"))

    def parse_date(s):
        try:
            return datetime.strptime(s, '%Y-%m-%d') if s else None
        except Exception:
            return None

    start_dt = parse_date(start_date_str)
    end_dt = parse_date(end_date_str)

    if start_dt:
        query = query.filter(Prediction.created_at >= start_dt)
    if end_dt:
        # include the whole end day
        query = query.filter(Prediction.created_at < end_dt.replace(hour=23, minute=59, second=59))

    preds = query.order_by(Prediction.created_at.desc()).all()

    return render_template('history.html', predictions=preds, label_filter=label_filter, start_date=start_date_str, end_date=end_date_str)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
