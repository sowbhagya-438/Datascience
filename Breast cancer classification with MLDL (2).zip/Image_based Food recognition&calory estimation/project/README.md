# Image-based Food Recognition & Calorie Estimation (Flask)

A Flask web app where users can upload a food image to get a predicted food label and estimated calories, view history, and see a dashboard with charts. Includes registration, login, and event tracking. Uses SQLite in the `instance/` folder.

## Features
- User registration/login/logout (password hashing)
- Upload image for dummy food prediction and calorie estimation
- Store predictions per user (with timestamp)
- Dashboard with Plotly charts: calorie distribution, per-user counts, and user trend
- History with filters and image thumbnails
- Event tracking for register, login, predict

## Tech Stack
- Flask, Flask-Login, Flask-SQLAlchemy
- SQLite (stored under `instance/app.db`)
- Plotly for charts

## Setup
1. Create and activate a virtual environment (recommended):
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
```
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the app:
```bash
python app.py
```
4. Open in browser: `http://127.0.0.1:5000/`

## Notes
- Uploads are saved under `instance/uploads/`.
- This project uses a dummy prediction function based on filename keywords. Replace `dummy_food_model_predict` in `app.py` with your ML model integration.
- For production, set `SECRET_KEY` via environment variable and run behind a proper WSGI server.
