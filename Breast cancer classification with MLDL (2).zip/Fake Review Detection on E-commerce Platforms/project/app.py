import os
import io
import pickle
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect as sa_inspect
from werkzeug.security import generate_password_hash, check_password_hash

# Visualization
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# ML / preprocessing
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression


def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')

    # Ensure instance folder exists
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    # SQLite DB inside instance/
    db_path = os.path.join(app.instance_path, 'app.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db = SQLAlchemy(app)

    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        username = db.Column(db.String(80), unique=True, nullable=False)
        email = db.Column(db.String(120), unique=True, nullable=False)
        password_hash = db.Column(db.String(200), nullable=False)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)

        def set_password(self, password):
            self.password_hash = generate_password_hash(password)

        def check_password(self, password):
            return check_password_hash(self.password_hash, password)

    class ActionLog(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
        action = db.Column(db.String(50), nullable=False)  # 'register', 'login', 'predict'
        details = db.Column(db.Text, nullable=True)
        timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    class Prediction(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
        review_text = db.Column(db.Text, nullable=False)
        rating = db.Column(db.Integer, nullable=True)
        predicted_label = db.Column(db.String(10), nullable=False)  # 'fake' or 'real'
        predicted_prob_fake = db.Column(db.Float, nullable=False)   # probability of fake
        created_at = db.Column(db.DateTime, default=datetime.utcnow)

    with app.app_context():
        # Ensure schema matches current models; reset if outdated
        needs_reset = False
        try:
            inspector = sa_inspect(db.engine)
            table_names = set(inspector.get_table_names())
            if 'prediction' in table_names:
                cols = {c['name'] for c in inspector.get_columns('prediction')}
                expected = {
                    'id', 'user_id', 'review_text', 'rating',
                    'predicted_label', 'predicted_prob_fake', 'created_at'
                }
                if not expected.issubset(cols):
                    needs_reset = True
            else:
                # no prediction table → let create_all handle it
                pass
        except Exception:
            # If inspection fails, fallback to reset
            needs_reset = True

        if needs_reset:
            db.drop_all()
        db.create_all()

    # Model and vectorizer paths (NLP fake review detection)
    MODEL_PATH = os.path.join(os.path.dirname(__file__), 'fake_review_model.pkl')
    VECT_PATH = os.path.join(os.path.dirname(__file__), 'vectorizer.pkl')

    def load_or_create_model():
        model = None
        vectorizer = None
        if os.path.exists(MODEL_PATH) and os.path.exists(VECT_PATH):
            try:
                with open(MODEL_PATH, 'rb') as f:
                    model = pickle.load(f)
                with open(VECT_PATH, 'rb') as f:
                    vectorizer = pickle.load(f)
            except Exception:
                model = None
                vectorizer = None
        if model is None or vectorizer is None:
            # Create a tiny synthetic dataset for demo purposes
            fake_reviews = [
                "Best product ever!!! Get it now!!!",
                "Amazing deal, unbelievable price, five stars guaranteed",
                "This changed my life, I will buy 10 more, hurry!",
                "Official seller offers exclusive discount!!!",
                "Perfect quality, perfect shipping, perfect everything!!!",
            ]
            real_reviews = [
                "Item arrived as described. Quality is decent for the price.",
                "The packaging was okay and the product works as expected.",
                "Not bad, but the battery life could be better.",
                "Fast delivery. Fits my needs, would consider buying again.",
                "Color is slightly different than pictured, otherwise fine.",
            ]
            texts = fake_reviews + real_reviews
            labels = np.array([1] * len(fake_reviews) + [0] * len(real_reviews))  # 1=fake, 0=real

            vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=5000)
            X = vectorizer.fit_transform(texts)
            model = LogisticRegression(max_iter=1000)
            model.fit(X, labels)

            try:
                with open(MODEL_PATH, 'wb') as f:
                    pickle.dump(model, f)
                with open(VECT_PATH, 'wb') as f:
                    pickle.dump(vectorizer, f)
            except Exception:
                pass
        return model, vectorizer

    model, vectorizer = load_or_create_model()

    # Helpers
    def current_user():
        user_id = session.get('user_id')
        if not user_id:
            return None
        return db.session.get(User, user_id)

    def login_required(view_func):
        from functools import wraps

        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user():
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('login'))
            return view_func(*args, **kwargs)

        return wrapped

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            email = request.form.get('email', '').strip().lower()
            password = request.form.get('password', '')
            confirm = request.form.get('confirm', '')

            if not username or not email or not password:
                flash('All fields are required.', 'danger')
                return render_template('register.html')
            if password != confirm:
                flash('Passwords do not match.', 'danger')
                return render_template('register.html')
            if User.query.filter((User.username == username) | (User.email == email)).first():
                flash('Username or email already exists.', 'danger')
                return render_template('register.html')

            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()

            db.session.add(ActionLog(user_id=user.id, action='register', details=f'user {username}'))
            db.session.commit()

            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('login'))

        return render_template('register.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                session['user_id'] = user.id
                db.session.add(ActionLog(user_id=user.id, action='login', details='success'))
                db.session.commit()
                flash('Logged in successfully.', 'success')
                return redirect(url_for('dashboard'))
            flash('Invalid username or password.', 'danger')
        return render_template('login.html')

    @app.route('/logout')
    def logout():
        session.clear()
        flash('You have been logged out.', 'info')
        return redirect(url_for('index'))

    @app.route('/predict', methods=['GET', 'POST'])
    @login_required
    def predict():
        if request.method == 'POST':
            text = (request.form.get('review_text') or '').strip()
            rating_str = request.form.get('rating')
            try:
                rating = int(rating_str) if rating_str else None
            except ValueError:
                rating = None

            if not text:
                flash('Please enter review text.', 'danger')
                return render_template('predict.html')

            X = vectorizer.transform([text])
            proba = float(model.predict_proba(X)[0][1])  # probability of class=1 (fake)
            label = 'fake' if proba >= 0.5 else 'real'

            pred = Prediction(
                user_id=current_user().id,
                review_text=text,
                rating=rating,
                predicted_label=label,
                predicted_prob_fake=proba,
            )
            db.session.add(pred)
            db.session.add(ActionLog(user_id=current_user().id, action='predict', details=f'label={label};prob={proba:.3f}'))
            db.session.commit()

            return redirect(url_for('result', prediction_id=pred.id))

        return render_template('predict.html')

    @app.route('/result')
    @login_required
    def result():
        prediction_id = request.args.get('prediction_id')
        pred = None
        if prediction_id:
            pred = Prediction.query.filter_by(id=prediction_id, user_id=current_user().id).first()
        return render_template('prediction_result.html', prediction=pred)

    def _plot_prob_distribution(probs):
        fig, ax = plt.subplots(figsize=(6, 4))
        sns.histplot(probs, kde=True, ax=ax, color='#4e79a7', binwidth=0.05, binrange=(0,1))
        ax.set_title('Distribution of Fake Probabilities')
        ax.set_xlabel('P(fake)')
        ax.set_ylabel('Count')
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format='png')
        plt.close(fig)
        buf.seek(0)
        return buf

    def _plot_counts_per_user(data):
        fig, ax = plt.subplots(figsize=(6, 4))
        users = list(data.keys())
        counts = list(data.values())
        ax.bar(users, counts, color='#59a14f')
        ax.set_title('Number of Predictions per User')
        ax.set_xlabel('User')
        ax.set_ylabel('Predictions')
        plt.xticks(rotation=30, ha='right')
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format='png')
        plt.close(fig)
        buf.seek(0)
        return buf

    def _plot_trend(dates, probs):
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(dates, probs, marker='o', color='#e15759')
        ax.set_title('Average P(fake) Over Time')
        ax.set_xlabel('Time')
        ax.set_ylabel('P(fake)')
        plt.xticks(rotation=30, ha='right')
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format='png')
        plt.close(fig)
        buf.seek(0)
        return buf

    def _plot_class_distribution(fake_count, real_count):
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(['fake', 'real'], [fake_count, real_count], color=['#e15759', '#59a14f'])
        ax.set_title('Predicted Class Distribution')
        ax.set_ylabel('Count')
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format='png')
        plt.close(fig)
        buf.seek(0)
        return buf

    @app.route('/dashboard')
    @login_required
    def dashboard():
        user = current_user()
        preds = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.asc()).all()
        probs = [p.predicted_prob_fake for p in preds] if preds else [0.0]
        labels = [p.predicted_label for p in preds] if preds else []
        fake_count = sum(1 for l in labels if l == 'fake')
        real_count = sum(1 for l in labels if l == 'real')

        summary = {
            'total_predictions': len(preds),
            'avg_prob_fake': float(np.mean(probs)) if preds else 0.0,
            'pct_fake': float(100.0 * fake_count / len(preds)) if preds else 0.0,
        }

        # Build plots into in-memory images and serve via endpoints
        session['dash_cache'] = True  # marker
        return render_template('dashboard.html', summary=summary)

    @app.route('/dashboard/prob_distribution.png')
    @login_required
    def prob_distribution_png():
        user = current_user()
        preds = Prediction.query.filter_by(user_id=user.id).all()
        probs = [p.predicted_prob_fake for p in preds] if preds else [0.0]
        buf = _plot_prob_distribution(probs)
        return send_file(buf, mimetype='image/png')

    @app.route('/dashboard/predictions_per_user.png')
    @login_required
    def predictions_per_user_png():
        # Counts per user across all users
        rows = db.session.execute(
            db.select(User.username, db.func.count(Prediction.id)).join(Prediction, Prediction.user_id == User.id, isouter=True).group_by(User.id)
        ).all()
        data = {username: count for username, count in rows}
        if not data:
            data = {'no-data': 0}
        buf = _plot_counts_per_user(data)
        return send_file(buf, mimetype='image/png')

    @app.route('/dashboard/trend.png')
    @login_required
    def trend_png():
        user = current_user()
        preds = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.asc()).all()
        dates = [p.created_at for p in preds] if preds else [datetime.utcnow()]
        probs = [p.predicted_prob_fake for p in preds] if preds else [0.0]
        buf = _plot_trend(dates, probs)
        return send_file(buf, mimetype='image/png')

    @app.route('/dashboard/class_distribution.png')
    @login_required
    def class_distribution_png():
        user = current_user()
        preds = Prediction.query.filter_by(user_id=user.id).all()
        labels = [p.predicted_label for p in preds]
        fake_count = sum(1 for l in labels if l == 'fake')
        real_count = sum(1 for l in labels if l == 'real')
        buf = _plot_class_distribution(fake_count, real_count)
        return send_file(buf, mimetype='image/png')

    @app.route('/history')
    @login_required
    def history():
        user = current_user()
        # Filters
        label = request.args.get('label')  # 'fake' or 'real'
        min_prob = request.args.get('min_prob')
        max_prob = request.args.get('max_prob')
        q = Prediction.query.filter_by(user_id=user.id)
        if label in ('fake', 'real'):
            q = q.filter(Prediction.predicted_label == label)
        if min_prob:
            try:
                q = q.filter(Prediction.predicted_prob_fake >= float(min_prob))
            except ValueError:
                pass
        if max_prob:
            try:
                q = q.filter(Prediction.predicted_prob_fake <= float(max_prob))
            except ValueError:
                pass
        preds = q.order_by(Prediction.created_at.desc()).all()
        return render_template('history.html', predictions=preds)

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))


