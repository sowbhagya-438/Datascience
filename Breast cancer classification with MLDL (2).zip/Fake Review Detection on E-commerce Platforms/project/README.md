# Fake Review Detection on E-Commerce Platforms (Flask App)

This Flask app detects potentially fake product reviews. It includes user authentication, a review analysis form, action tracking, dashboards with charts, and a history view. A light-weight NLP model (TF-IDF + Logistic Regression) is auto-generated for demo purposes if one is not present.

## Features
- User registration/login with password hashing (SQLite in `instance/app.db`).
- Review analysis form that saves inputs/outputs per user.
- Dashboard with charts: distribution of P(fake), predictions per user, class distribution, and trend over time.
- History page with filters by label and probability range.
- All actions tracked in DB (`ActionLog`: register, login, predict).
- Model and vectorizer auto-generated if missing.

## Project Structure
```
project/
  app.py
  requirements.txt
  README.md
  fake_review_model.pkl
  vectorizer.pkl
  static/
    style.css
  templates/
    base.html
    index.html
    login.html
    register.html
    predict.html
    prediction_result.html
    dashboard.html
    history.html
  instance/
    app.db (created at runtime)
```

## Setup
1. Create and activate a virtual environment.
   - Windows PowerShell:
     ```powershell
     python -m venv .venv
     .venv\\Scripts\\Activate.ps1
     ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python app.py
   ```
4. Open `http://127.0.0.1:5000/` in your browser.

## Environment
- `SECRET_KEY` (optional): set to override default dev key.

## Notes
- The database file is created under `instance/app.db`. Delete it to reset.
- If `house_price_model.pkl` or `scaler.pkl` are missing/corrupt, a dummy model is trained automatically and persisted.


