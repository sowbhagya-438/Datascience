# AQI Predictor (Flask)

A Flask web app to predict Air Quality Index (AQI) using a regression model. Includes user authentication, prediction history, and a dashboard with charts.

## Features
- User registration/login (SQLite, password hashing)
- Predict AQI from pollutants and weather inputs
- Stores each prediction with timestamp per user
- Dashboard with charts (matplotlib/seaborn)
- History with date filters

## Tech
- Flask, Flask-SQLAlchemy
- scikit-learn (LinearRegression), StandardScaler
- matplotlib, seaborn
- SQLite (stored in `instance/app.db`)

## Setup
1. Create virtual environment and install requirements
```bash
python -m venv venv
venv\Scripts\activate  # Windows PowerShell
pip install -r requirements.txt
```

2. Run the app
```bash
$env:FLASK_APP = "app.py"
python app.py
# open http://127.0.0.1:5000
```

## Notes
- If `aqi_model.pkl` or `scaler.pkl` are missing, a synthetic model is generated on first run.
- All data (users, predictions, activity logs) are stored in `instance/app.db`.

## Routes
- `/` Home
- `/login`, `/register`, `/logout`
- `/predict` prediction form
- `/result?prediction_id=<id>` result page
- `/dashboard` charts and summary
- `/history` your predictions list

## License
MIT
