import os
import io
import uuid
import pickle
from datetime import datetime
from typing import Tuple

from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# Visualization
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# ML
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression


BASE_DIR = os.path.abspath(os.path.dirname(__file__))


def create_app() -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
    db_path = os.path.join(app.instance_path, 'app.db')
    os.makedirs(app.instance_path, exist_ok=True)
    app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{db_path}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    return app


app = create_app()
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    predictions = db.relationship('Prediction', backref='user', lazy=True)


class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    # AQI feature inputs (example common pollutants and weather)
    pm25 = db.Column(db.Float, nullable=False)
    pm10 = db.Column(db.Float, nullable=False)
    no2 = db.Column(db.Float, nullable=False)
    so2 = db.Column(db.Float, nullable=False)
    co = db.Column(db.Float, nullable=False)
    o3 = db.Column(db.Float, nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    humidity = db.Column(db.Float, nullable=False)
    wind_speed = db.Column(db.Float, nullable=False)
    prediction_value = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    action = db.Column(db.String(50), nullable=False)  # register, login, predict
    details = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


def get_model_paths() -> Tuple[str, str]:
    model_path = os.path.join(BASE_DIR, 'house_price_model.pkl')
    scaler_path = os.path.join(BASE_DIR, 'scaler.pkl')
    return model_path, scaler_path


def generate_dummy_model_if_missing():
    model_path, scaler_path = get_model_paths()
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        return

    rng = np.random.default_rng(42)
    n = 1000
    # Features: pm25, pm10, no2, so2, co, o3, temperature, humidity, wind_speed
    X = np.column_stack([
        rng.normal(60, 30, n).clip(2, 500),   # pm25
        rng.normal(100, 40, n).clip(5, 600),  # pm10
        rng.normal(25, 10, n).clip(1, 200),   # no2
        rng.normal(10, 5, n).clip(0.1, 100),  # so2
        rng.normal(0.8, 0.3, n).clip(0.05, 10),  # co (ppm)
        rng.normal(40, 15, n).clip(2, 300),   # o3
        rng.normal(22, 8, n).clip(-10, 50),   # temperature Celsius
        rng.normal(55, 20, n).clip(5, 100),   # humidity %
        rng.normal(2.5, 1.2, n).clip(0, 15),  # wind_speed m/s
    ])
    # A synthetic AQI-like target: weighted sum + noise
    weights = np.array([0.5, 0.3, 0.2, 0.15, 10.0, 0.25, -0.2, 0.05, -0.3])
    y = (X @ weights) + rng.normal(0, 10, n)
    y = np.clip(y, 0, 500)

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    model = LinearRegression()
    model.fit(Xs, y)

    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)


def load_model_and_scaler():
    generate_dummy_model_if_missing()
    model_path, scaler_path = get_model_paths()
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    with open(scaler_path, 'rb') as f:
        scaler = pickle.load(f)
    return model, scaler


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return User.query.get(uid)


def login_required(view_func):
    from functools import wraps

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return view_func(*args, **kwargs)

    return wrapped


def classify_aqi(aqi_value: float) -> Tuple[str, str]:
    # Returns (status_label, color_key)
    if aqi_value <= 50:
        return 'Good', 'good'
    if aqi_value <= 100:
        return 'Moderate', 'moderate'
    if aqi_value <= 150:
        return 'Unhealthy for Sensitive Groups', 'usg'
    if aqi_value <= 200:
        return 'Unhealthy', 'unhealthy'
    if aqi_value <= 300:
        return 'Very Unhealthy', 'veryunhealthy'
    return 'Hazardous', 'hazardous'


# Create database tables at startup (Flask 3 removed before_first_request)
with app.app_context():
    db.create_all()


@app.route('/')
def index():
    return render_template('index.html', user=current_user())


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return render_template('register.html')

        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or email already exists.', 'danger')
            return render_template('register.html')

        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password)
        )
        db.session.add(user)
        db.session.commit()

        db.session.add(ActivityLog(user_id=user.id, action='register', details=f'user:{username}'))
        db.session.commit()
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email_or_username = request.form.get('email_or_username', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter(
            (User.email == email_or_username) | (User.username == email_or_username)
        ).first()
        if not user or not check_password_hash(user.password_hash, password):
            db.session.add(ActivityLog(user_id=user.id if user else None, action='login', details='failed'))
            db.session.commit()
            flash('Invalid credentials.', 'danger')
            return render_template('login.html')
        session['user_id'] = user.id
        db.session.add(ActivityLog(user_id=user.id, action='login', details='success'))
        db.session.commit()
        flash('Logged in successfully.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    uid = session.pop('user_id', None)
    if uid:
        db.session.add(ActivityLog(user_id=uid, action='logout', details=''))
        db.session.commit()
    flash('Logged out.', 'info')
    return redirect(url_for('index'))


@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    if request.method == 'POST':
        try:
            fields = ['pm25','pm10','no2','so2','co','o3','temperature','humidity','wind_speed']
            values = [float(request.form.get(k, '0')) for k in fields]
        except ValueError:
            flash('Please enter valid numeric values.', 'danger')
            return render_template('predict.html')

        model, scaler = load_model_and_scaler()
        arr = np.array(values, dtype=float).reshape(1, -1)
        arr_scaled = scaler.transform(arr)
        pred = float(model.predict(arr_scaled)[0])
        pred = max(0.0, min(500.0, pred))

        user = current_user()
        rec = Prediction(
            user_id=user.id,
            pm25=values[0], pm10=values[1], no2=values[2], so2=values[3], co=values[4], o3=values[5],
            temperature=values[6], humidity=values[7], wind_speed=values[8],
            prediction_value=pred,
        )
        db.session.add(rec)
        db.session.add(ActivityLog(user_id=user.id, action='predict', details=f'pred:{pred:.2f}'))
        db.session.commit()

        return redirect(url_for('result', prediction_id=rec.id))

    return render_template('predict.html')


@app.route('/result')
@login_required
def result():
    pid = request.args.get('prediction_id', type=int)
    if not pid:
        flash('Prediction not found.', 'warning')
        return redirect(url_for('predict'))
    rec = Prediction.query.get_or_404(pid)
    if rec.user_id != current_user().id:
        flash('You cannot view this prediction.', 'danger')
        return redirect(url_for('history'))
    status_label, status_color = classify_aqi(rec.prediction_value)
    return render_template('prediction_result.html', prediction=rec, aqi_status=status_label, aqi_status_color=status_color)


def _render_chart_to_png_bytes(fig) -> bytes:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format='png')
    plt.close(fig)
    buf.seek(0)
    return buf.read()


@app.route('/chart/<chart_id>.png')
@login_required
def chart_image(chart_id: str):
    user = current_user()
    qs = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.asc())
    preds = [p.prediction_value for p in qs]
    times = [p.created_at for p in qs]

    if chart_id == 'distribution':
        fig, ax = plt.subplots(figsize=(6, 4))
        if preds:
            sns.histplot(preds, bins=20, kde=True, ax=ax)
        ax.set_title('Distribution of Predicted AQI')
        ax.set_xlabel('Predicted AQI')
        ax.set_ylabel('Count')
        data = _render_chart_to_png_bytes(fig)
    elif chart_id == 'over_time':
        fig, ax = plt.subplots(figsize=(6, 4))
        if preds:
            ax.plot(times, preds, marker='o')
        ax.set_title('Predicted AQI Over Time')
        ax.set_xlabel('Time')
        ax.set_ylabel('Predicted AQI')
        data = _render_chart_to_png_bytes(fig)
    elif chart_id == 'per_user':
        # For single-user view, this shows count of predictions by this user
        fig, ax = plt.subplots(figsize=(4, 4))
        ax.bar(['You'], [len(preds)])
        ax.set_title('Number of Predictions (You)')
        data = _render_chart_to_png_bytes(fig)
    else:
        return redirect(url_for('dashboard'))

    return send_file(io.BytesIO(data), mimetype='image/png')


@app.route('/dashboard')
@login_required
def dashboard():
    user = current_user()
    qs = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.desc())
    count = qs.count()
    last = qs.first()
    avg = db.session.query(db.func.avg(Prediction.prediction_value)).filter_by(user_id=user.id).scalar()
    avg = float(avg) if avg is not None else None
    return render_template('dashboard.html', count=count, last=last, avg=avg)


@app.route('/history')
@login_required
def history():
    user = current_user()
    start = request.args.get('start')
    end = request.args.get('end')
    q = Prediction.query.filter_by(user_id=user.id)
    if start:
        try:
            dt = datetime.fromisoformat(start)
            q = q.filter(Prediction.created_at >= dt)
        except ValueError:
            pass
    if end:
        try:
            dt = datetime.fromisoformat(end)
            q = q.filter(Prediction.created_at <= dt)
        except ValueError:
            pass
    q = q.order_by(Prediction.created_at.desc())
    items = q.all()
    return render_template('history.html', items=items)


if __name__ == '__main__':
    # For local dev
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)


